<?php
// variable system
echo 'Dokumen Root '.$_SERVER["DOCUMENT ROOT"];
echo '<br/>Nama File '.$_SERVER["PHP-SELF"];
?>